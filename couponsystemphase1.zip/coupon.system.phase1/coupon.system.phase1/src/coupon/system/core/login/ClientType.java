package coupon.system.core.login;

public enum ClientType {

	Administrator, Company, Customer

}
