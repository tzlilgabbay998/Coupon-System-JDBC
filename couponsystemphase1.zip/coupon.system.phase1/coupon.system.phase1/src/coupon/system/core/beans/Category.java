package coupon.system.core.beans;

public enum Category {

	DRINKS, FRUITS, VEGETABLES, FROZEN, HOME_CLOTHING, ELECTRICITY

}
